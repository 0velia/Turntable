# Turntable

A browser-based 3D model viewer and converter. Everything runs locally in the browser, and the app works fully offline: all libraries and fonts are included in this repo. No files are uploaded anywhere.

## Formats

**Open:** GLB, glTF, OBJ, STL, PLY, DAE, FBX, 3DS, 3MF, AMF, WRL (VRML), KMZ, VTK

**Convert to:** GLB, glTF, OBJ, STL, PLY, DAE

For models with separate texture files (for example a DAE or OBJ), select the model and its textures together.

## Features

- Orbit, pan and zoom viewer with auto-fit
- Shading modes: solid, wireframe, solid + wireframe (adjustable color and opacity) for checking mesh density
- Vertex, triangle and size readout
- Compact DAE writer for dense meshes
- Fallback reader for slicer-style 3MF files

## Run it

Open `index.html` in a browser, or publish the repo with GitHub Pages
(Settings > Pages > deploy from the main branch, root folder). Keep the `libs/` and `fonts/` folders next to `index.html`.

## Contents

- `index.html` is the whole app
- `libs/` holds three.js r128 (with the loaders and exporters used), JSZip, fflate and chevrotain
- `fonts/` holds the Schibsted Grotesk font files (SIL Open Font License)

## Third-party licenses

- three.js: MIT (`libs/LICENSE-three.txt`)
- JSZip: MIT or GPLv3 (`libs/LICENSE-jszip.md`)
- fflate: MIT (`libs/LICENSE-fflate.txt`)
- chevrotain (used by the VRML loader): Apache-2.0, https://github.com/Chevrotain/chevrotain
- Schibsted Grotesk font: SIL Open Font License 1.1
